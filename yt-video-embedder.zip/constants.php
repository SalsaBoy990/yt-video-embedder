<?php

// this constant is global on purpose
define('AG_YT_VIDEO_EMBEDDER_PLUGIN_DIR', plugin_dir_path(__FILE__));
