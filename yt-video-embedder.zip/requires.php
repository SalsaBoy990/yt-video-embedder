<?php

// constants
require_once 'constants.php';

// autoload dependencies
require_once 'autoload.php';
