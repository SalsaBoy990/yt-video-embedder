<?php

// this constant is global on purpose
define('AG_YTVIDEO_EMBEDDER_DEBUG', 0);

define('AG_YTVIDEO_EMBEDDER_LOGGING', 1);

define('AG_YT_VIDEO_EMBEDDER_PLUGIN_DIR', plugin_dir_path(__FILE__));
